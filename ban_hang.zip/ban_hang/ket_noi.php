<?php
    mysql_connect("localhost","root","");
    mysql_select_db("ban_hang");
    mysql_query('SET NAMES "UTF8"');
?> 