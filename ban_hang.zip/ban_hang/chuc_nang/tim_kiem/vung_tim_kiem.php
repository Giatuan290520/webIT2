Tìm kiếm <br>
<form>
    <input type="hidden" name="thamso" value="tim_kiem" >
    <input type="text" name="tu_khoa" value="" style="margin-top:10px;margin-bottom:10px;" >
    <input type="submit" value="Tìm" >
</form> 